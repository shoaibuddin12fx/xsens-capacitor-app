"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["v2_xsens-capacitor_dist_esm_web_js"],{

/***/ 480:
/*!*********************************************!*\
  !*** ../v2/xsens-capacitor/dist/esm/web.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "XsensCapacitorWeb": () => (/* binding */ XsensCapacitorWeb)
/* harmony export */ });
/* harmony import */ var _Users_shoaibuddin_Desktop_shoaib_AKU_xsens_capacitor_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @capacitor/core */ 7914);


class XsensCapacitorWeb extends _capacitor_core__WEBPACK_IMPORTED_MODULE_1__.WebPlugin {
  getBluetoothDevices() {
    return [];
  }

  getBluetoothPermission() {}

  initialize() {
    return true;
  }

  echo(options) {
    return (0,_Users_shoaibuddin_Desktop_shoaib_AKU_xsens_capacitor_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      console.log('ECHO', options);
      return options;
    })();
  }

  getPluginVersion() {
    return '1.0.5';
  }

}

/***/ })

}]);
//# sourceMappingURL=v2_xsens-capacitor_dist_esm_web_js.js.map